"""Shared utility functions."""







