"""Shared utility functions."""



